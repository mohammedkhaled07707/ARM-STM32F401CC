/******************************************************/
/* SWC: RCC Driver                                    */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 27 SEP 2023                                  */
/* Description: This is the implem. RCC               */
/******************************************************/


#ifndef RCC_PRIVATE_H_
#define RCC_PRIVATE_H_

#include "STD_TYPES.h"



/************* RCC BUS: AHB1    RCC BASE ADDRESS: 0x40023800    ******************/


#define RCC_BASE_ADDRESS 0x40023800


#define RCC_CR        *((volatile u32*)(RCC_BASE_ADDRESS))
#define RCC_PLLCFGR   *((volatile u32*)(RCC_BASE_ADDRESS+0x04))
#define RCC_CFGR      *((volatile u32*)(RCC_BASE_ADDRESS+0x08))
#define RCC_CIR       *((volatile u32*)(RCC_BASE_ADDRESS+0x0C))
#define RCC_AHB1RSTR  *((volatile u32*)(RCC_BASE_ADDRESS+0x10))
#define RCC_AHB2RSTR  *((volatile u32*)(RCC_BASE_ADDRESS+0x14))
#define RCC_APB1RSTR  *((volatile u32*)(RCC_BASE_ADDRESS+0x20))
#define RCC_APB2RSTR  *((volatile u32*)(RCC_BASE_ADDRESS+0x24))
#define RCC_AHB1ENR   *((volatile u32*)(RCC_BASE_ADDRESS+0x30))
#define RCC_AHB2ENR   *((volatile u32*)(RCC_BASE_ADDRESS+0x34))
#define RCC_APB1ENR   *((volatile u32*)(RCC_BASE_ADDRESS+0x40))
#define RCC_APB2ENR   *((volatile u32*)(RCC_BASE_ADDRESS+0x44))

/********************************************************************************/


#endif
