/******************************************************/
/* SWC: RCC Driver                                    */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 27 SEP 2023                                  */
/* Description: This is the implem. RCC               */
/******************************************************/



#ifndef RCC_CONFIG_H_
#define RCC_CONFIG_H_


/*******   SYSTEM CLOCK BYPASS  ******/

#define ENABLE  1
#define DISABLE 0

#define SYSCLK_BYPASS DISABLE

/***********************************/

/******* CLOCK SECURITY SYSTEM ******/

#define CLOCK_SECURITY_SYSTEM DISABLE

/***********************************/

/*********** CLOCK SOURCE **********/

#define HSI_CLOCK 0
#define HSE_CLOCK 1
#define PLL_CLOCK 2

#define CLOCK_SOURCE HSI_CLOCK

/**********************************/

/*********** AHB1 PRESCALAR *******/

#define NO_PRESCALAR   0
#define PRESCALAR_2    1
#define PRESCALAR_4    2
#define PRESCALAR_8    3
#define PRESCALAR_16   4
#define PRESCALAR_64   5
#define PRESCALAR_128  6
#define PRESCALAR_256  7
#define PRESCALAR_512  8

#define AHB_PRESCALAR PRESCALAR_2

/**********************************/












#endif
