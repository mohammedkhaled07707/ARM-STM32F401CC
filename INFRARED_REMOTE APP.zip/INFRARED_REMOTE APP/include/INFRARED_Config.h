
/******************************************************/
/* SWC: INFRARED Driver                               */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 13 OCT 2023                                  */
/* Description: This is the implem. INFRARED          */
/******************************************************/
#ifndef INFRARED_CONFIG_H_
#define INFRARED_CONFIG_H_



#define INFRARED_PORT         PORTA
#define INFRARED_PIN          PIN0
#define INFRARED_INTERRUPT    EXT0_LINE



#endif /* INFRARED_CONFIG_H_ */
