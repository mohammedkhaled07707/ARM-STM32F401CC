/******************************************************/
/* SWC: DMA Driver                                    */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 01 OCT 2023                                  */
/* Description: This is the implem. DMA               */
/******************************************************/
#ifndef DMA_PRIVATE_H_
#define DMA_PRIVATE_H_

#include "STD_TYPES.h"


typedef struct
{
	u32 CR;
	u32 NDTR;
	u32 PAR;
	u32 M0AR;
	u32 M1AR;
	u32 FCR;

}stream_t;


typedef struct
{

	u32 LISR;
	u32 HISR;
	u32 LIFCR;
	u32 HIFCR;
    stream_t ch[7];
}dma_t;





/******************** DMA1 BUS: AHB1   BASE ADDRESS: 0x40026000 **************************/

#define DMA1_BASE_ADDRESS 0x40026000


#define DMA ((volatile dma_t*)(DMA1_BASE_ADDRESS))


/*****************************************************************************************/

/******************** DMA2 BUS: AHB1   BASE ADDRESS: 0x40026400 **************************/

#define DMA2_BASE_ADDRESS 0x40026400


/*****************************************************************************************/

#endif /* DMA_PRIVATE_H_ */
