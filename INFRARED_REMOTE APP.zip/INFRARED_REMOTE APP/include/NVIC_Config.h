/******************************************************/
/* SWC: NVIC Driver                                   */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 30 SEP 2023                                  */
/* Description: This is the implem. NVIC              */
/******************************************************/

#ifndef NVIC_CONFIG_H_
#define NVIC_CONFIG_H_

/*********************** PRIORITY CONFIGURATION ***********************/

#define GROUP_16_SUB_0 3
#define GROUP_8_SUB_2  0b0100
#define GROUP_4_SUB_4  0b0101
#define GROUP_2_SUB_8  0b0110
#define GROUP_0_SUB_16 0b0111

#define PRIORITY GROUP_16_SUB_0

/**********************************************************************/



#endif /* NVIC_CONFIG_H_ */
