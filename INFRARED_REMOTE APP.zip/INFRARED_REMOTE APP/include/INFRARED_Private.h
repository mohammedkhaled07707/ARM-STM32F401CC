
/******************************************************/
/* SWC: INFRARED Driver                               */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 13 OCT 2023                                  */
/* Description: This is the implem. INFRARED          */
/******************************************************/
#ifndef INFRARED_PRIVATE_H_
#define INFRARED_PRIVATE_H_





#endif /* INFRARED_PRIVATE_H_ */
