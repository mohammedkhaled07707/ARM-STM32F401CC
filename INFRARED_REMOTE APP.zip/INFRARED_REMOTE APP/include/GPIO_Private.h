/******************************************************/
/* SWC: GPIO Driver                                   */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 28 SEP 2023                                  */
/* Description: This is the implem. GPIO              */
/******************************************************/


#ifndef GPIO_PRIVATE_H_
#define GPIO_PRIVATE_H_

#include "STD_TYPES.h"

typedef struct
{
	u32 MODER;
	u32 OTYPER;
	u32 OSPEEDR;
	u32 PUPDR;
	u32 IDR;
	u32 ODR;
	u32 BSRR;
	u32 LCKR;
	u32 AFRL;
	u32 AFRH;

}GPIO_TYPE;



/************* GPIOA BUS: AHB1    GPIOA BASE ADDRESS: 0x40020000    ******************/

#define GPIOA_BASE_ADDRESS 0x40020000

#define GPIOA_REG ((volatile GPIO_TYPE*)(0x40020000))

/*************************************************************************************/


/************* GPIOB BUS: AHB1    GPIOB BASE ADDRESS: 0x40020400    ******************/

#define GPIOB_BASE_ADDRESS 0x40020400

#define GPIOB_REG ((volatile GPIO_TYPE*)(0x40020400))

/*************************************************************************************/


/************* GPIOC BUS: AHB1    GPIOC BASE ADDRESS: 0x40020800    ******************/

#define GPIOC_BASE_ADDRESS 0x40020800

#define GPIOC_REG ((volatile GPIO_TYPE*)(0x40020800))

/*************************************************************************************/






#endif /* GPIO_PRIVATE_H_ */
