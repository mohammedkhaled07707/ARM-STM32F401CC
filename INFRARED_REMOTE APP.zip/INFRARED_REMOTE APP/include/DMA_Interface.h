/******************************************************/
/* SWC: DMA Driver                                    */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 01 OCT 2023                                  */
/* Description: This is the implem. DMA               */
/******************************************************/
#ifndef DMA_INTERFACE_H_
#define DMA_INTERFACE_H_

#include "STD_TYPES.h"




#endif /* DMA_INTERFACE_H_ */
