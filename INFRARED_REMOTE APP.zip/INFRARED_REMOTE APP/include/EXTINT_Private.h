/******************************************************/
/* SWC: EXTERNAL INTERRUPT DRIVER                     */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 28 SEP 2023                                  */
/* Description: This is the implem. EXTERNAL INTERRUPT*/
/******************************************************/

#ifndef EXTINT_PRIVATE_H_
#define EXTINT_PRIVATE_H_


#include "STD_TYPES.h"

typedef struct
{
	u32 IMR;
	u32 EMR;
	u32 RTSR;
	u32 FTSR;
	u32 SWIER;
	u32 PR;

}EXTI_t;

/************* SYSCFG BUS: APB2    SYSCFG BASE ADDRESS: 0x40013800   ******************/

#define SYSCFG_BASE_ADDRESS 0x40013800

#define SYSCFG_EXTICR ((volatile u32*)(SYSCFG_BASE_ADDRESS+0x08))

/***************************************************************************************/

/************* EXT BUS: APB2      EXTI BASE ADDRESS: 0x40013C00      ******************/

#define EXTI_BASE_ADDRESS 0x40013C00

#define EXTI ((volatile EXTI_t*)(EXTI_BASE_ADDRESS))

/***************************************************************************************/



#endif /* EXTINT_PRIVATE_H_ */
