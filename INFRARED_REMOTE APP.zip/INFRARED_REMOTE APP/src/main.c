

#include <stdio.h>
#include <stdlib.h>


#include "STD_TYPES.h"
#include "MACROS.h"
#include "RCC_Interface.h"
#include "GPIO_Interface.h"
#include "GPIO_Private.h"
#include "NVIC_Interface.h"
#include "SYSTICK_Interface.h"
#include "UART_Interface.h"
#include "EXTINT_Interface.h"
#include "EXTINT_Private.h"
#include "LED_MATRIX.h"
#include "DAC.h"
#include "SKYFALL_SONG.h"
#include "INFRARED_Interface.h"




u8 K_LETTER[8] = {0, 126, 16, 40, 68, 2, 0, 0};
u8 M_LETTER[8] = {254, 4, 8, 16, 8, 4, 254, 0};
u8 O_LETTER[8] = {224, 160, 224, 0, 0, 0, 0, 0};
u8 HEART[8] = {0, 28, 60, 124, 248, 124, 60, 28};
u8 N_LETTER[8] = {0, 252, 8, 16, 32, 64, 252, 0};
u8 R_LETTER[8] = {0, 252, 36, 36, 100, 164, 60, 0};


u8 reading = 0;
u8 val = 0;

void toggle()
{
	val = val ^ 1;
	GPIO_voidSetPinVal(PORTA,PIN1,val);
}



int main()
{


EXTI_voidSetCallBack(EXT0_LINE,INFRARED_voidRecieve);

/*RCC_VoidSysClkEnable();
RCC_VoidPerClkEnable(AHB1_BUS,GPIOA);
RCC_VoidPerClkEnable(AHB1_BUS,GPIOB);
SYSTICK_voidInit();
LEDMATRIX_voidInit();*/

RCC_VoidSysClkEnable();
RCC_VoidPerClkEnable(AHB1_BUS,GPIOA);
RCC_VoidPerClkEnable(AHB1_BUS,GPIOB);
SYSTICK_voidInit();
NVIC_voidInit();

GPIO_voidSetPinMode(PORTA,PIN0,INPUT_MODE);
GPIO_voidSetPinMode(PORTA,PIN1,OUTPUT_MODE);
GPIO_voidSetPinMode(PORTA,PIN2,OUTPUT_MODE);
GPIO_voidSetPinMode(PORTA,PIN3,OUTPUT_MODE);

GPIO_voidSetInputPUPD(PORTA,PIN0,PULLUP_MODE);
GPIO_voidSetOutputMode(PORTA,PIN1,PUSH_PULL_MODE);
GPIO_voidSetOutputMode(PORTA,PIN2,PUSH_PULL_MODE);
GPIO_voidSetOutputMode(PORTA,PIN3,PUSH_PULL_MODE);

GPIO_voidSetSpeed(PORTA,PIN0,LOW_SPEED_MODE);
GPIO_voidSetSpeed(PORTA,PIN1,LOW_SPEED_MODE);
GPIO_voidSetSpeed(PORTA,PIN2,LOW_SPEED_MODE);
GPIO_voidSetSpeed(PORTA,PIN3,LOW_SPEED_MODE);

NVIC_voidSetIntEnable(6);

EXTI_voidSetExtPinConfig(PORTA,PIN0);
EXTI_voidSetSenseControl(FALLING_EDGE,EXT0_LINE);
EXTI_voidSetExtLineEnable(EXT0_LINE);



//DAC_voidInit();





while(1)
{

//	DAC_voidPlaySong(48390,skyfall_raw);
	reading = INFRARED_voidGetReading();
    if (reading == REMOTE_1)
    {
    	GPIO_voidSetPinVal(PORTA,PIN1,HIGH);
    	GPIO_voidSetPinVal(PORTA,PIN2,LOW);
    	GPIO_voidSetPinVal(PORTA,PIN3,LOW);
    }

    if (reading == REMOTE_2)
    {
    	GPIO_voidSetPinVal(PORTA,PIN1,LOW);
    	GPIO_voidSetPinVal(PORTA,PIN2,HIGH);
    	GPIO_voidSetPinVal(PORTA,PIN3,LOW);
    }

    if (reading == REMOTE_3)
    {
    	GPIO_voidSetPinVal(PORTA,PIN1,LOW);
    	GPIO_voidSetPinVal(PORTA,PIN2,LOW);
    	GPIO_voidSetPinVal(PORTA,PIN3,HIGH);
    }

}


return 0;
}




