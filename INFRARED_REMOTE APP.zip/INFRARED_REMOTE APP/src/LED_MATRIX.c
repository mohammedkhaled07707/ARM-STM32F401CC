/******************************************************/
/* SWC: LED MATRIX Driver                             */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 06 OCT 2023                                  */
/* Description: This is the implem. LED MATRIX        */
/******************************************************/

#include "GPIO_Interface.h"
#include "SYSTICK_Interface.h"
#include "LED_MATRIX.h"
#include "stdio.h"
#include "MACROS.h"


/******************************************************/
/* Func. Name: LEDMATRIX_voidInit            	      */
/* i/p arguments:NOTHING                              */
/* o/p arguments:NOTHING                              */
/* Desc. : INTIALIZE THE LED MATRIX                   */
/******************************************************/

void LEDMATRIX_voidInit()
{

   // SET LED MATRIX PINS AS OUTPUT


	GPIO_voidSetPinMode(LED_MATRIX_COL_0,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_COL_1,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_COL_2,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_COL_3,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_COL_4,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_COL_5,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_COL_6,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_COL_7,OUTPUT_MODE);

	GPIO_voidSetPinMode(LED_MATRIX_ROW_0,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_ROW_1,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_ROW_2,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_ROW_3,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_ROW_4,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_ROW_5,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_ROW_6,OUTPUT_MODE);
	GPIO_voidSetPinMode(LED_MATRIX_ROW_7,OUTPUT_MODE);

   //////////////////////////////////


   // SET LED MATRIX PINS AS OUTPUT PUSH PULL

	GPIO_voidSetOutputMode(LED_MATRIX_COL_0,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_COL_1,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_COL_2,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_COL_3,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_COL_4,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_COL_5,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_COL_6,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_COL_7,PUSH_PULL_MODE);

	GPIO_voidSetOutputMode(LED_MATRIX_ROW_0,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_ROW_1,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_ROW_2,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_ROW_3,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_ROW_4,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_ROW_5,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_ROW_6,PUSH_PULL_MODE);
	GPIO_voidSetOutputMode(LED_MATRIX_ROW_7,PUSH_PULL_MODE);

	//////////////////////////////////


	// DISABLE THE LED MATRIX PINS

	GPIO_voidSetPinVal(LED_MATRIX_COL_0,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_1,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_2,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_3,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_4,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_5,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_6,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_7,HIGH);

	GPIO_voidSetPinVal(LED_MATRIX_ROW_0,LOW);
	GPIO_voidSetPinVal(LED_MATRIX_ROW_1,LOW);
	GPIO_voidSetPinVal(LED_MATRIX_ROW_2,LOW);
	GPIO_voidSetPinVal(LED_MATRIX_ROW_3,LOW);
	GPIO_voidSetPinVal(LED_MATRIX_ROW_4,LOW);
	GPIO_voidSetPinVal(LED_MATRIX_ROW_5,LOW);
	GPIO_voidSetPinVal(LED_MATRIX_ROW_6,LOW);
	GPIO_voidSetPinVal(LED_MATRIX_ROW_7,LOW);

	//////////////////////////////////

}

/******************************************************/
/* Func. Name: LEDMATRIX_voidTurnOff                  */
/* i/p arguments:NOTHING                              */
/* o/p arguments:NOTHING                              */
/* Desc. : TURNS OF THE LED MATRIX                    */
/******************************************************/

void LEDMATRIX_voidTurnOff()
{

	// SET ALL THE COLOUMNS TO HIGH TO DISABLE THE LED MATRIX

	GPIO_voidSetPinVal(LED_MATRIX_COL_0,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_1,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_2,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_3,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_4,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_5,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_6,HIGH);
	GPIO_voidSetPinVal(LED_MATRIX_COL_7,HIGH);

}

/******************************************************/
/* Func. Name: LEDMATRIX_voidRowDisp                  */
/* i/p arguments:Copy_u8Val >> NUMBER FROM 0 >> 255   */
/* o/p arguments:NOTHING                              */
/* Desc. : DISPLAY THE LEDS ON A CERTAIN ROW          */
/******************************************************/

void LEDMATRIX_voidRowDisp(u8 Copy_u8Val)
{

	// GET THE VALUE OF EACH BIT AND DISPLAY IT

	GPIO_voidSetPinVal(LED_MATRIX_ROW_0,GET_BIT(Copy_u8Val,0));
	GPIO_voidSetPinVal(LED_MATRIX_ROW_1,GET_BIT(Copy_u8Val,1));
	GPIO_voidSetPinVal(LED_MATRIX_ROW_2,GET_BIT(Copy_u8Val,2));
	GPIO_voidSetPinVal(LED_MATRIX_ROW_3,GET_BIT(Copy_u8Val,3));
	GPIO_voidSetPinVal(LED_MATRIX_ROW_4,GET_BIT(Copy_u8Val,4));
	GPIO_voidSetPinVal(LED_MATRIX_ROW_5,GET_BIT(Copy_u8Val,5));
	GPIO_voidSetPinVal(LED_MATRIX_ROW_6,GET_BIT(Copy_u8Val,6));
	GPIO_voidSetPinVal(LED_MATRIX_ROW_7,GET_BIT(Copy_u8Val,7));

}

/**************************************************************************/
/* Func. Name: LEDMATRIX_voidDispChar                                     */
/* i/p arguments:  PTR_ARR >> POINTER TO THE ARRAY NEEDED TO BE DISPLAYED */
/* o/p arguments:NOTHING                                                  */
/* Desc. : DISPLAYS A CHARACTER USING THE ARRAY GIVEN TO THE FUNCTION     */
/**************************************************************************/

void LEDMATRIX_voidDispChar(u8 *PTR_ARR)
{


	    LEDMATRIX_voidTurnOff();                       // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[0]);             // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(LED_MATRIX_COL_0,LOW);      // SELECT COLOUMN 0
		SYSTICK_voidBusyWait(10);                      // SHOW THE ROW FOR 10 Ms


	    LEDMATRIX_voidTurnOff();                       // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[1]);             // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(LED_MATRIX_COL_1,LOW);      // SELECT COLOUMN 1
		SYSTICK_voidBusyWait(10);                      // SHOW THE ROW FOR 10 Ms

	    LEDMATRIX_voidTurnOff();                       // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[2]);             // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(LED_MATRIX_COL_2,LOW);      // SELECT COLOUMN 2
		SYSTICK_voidBusyWait(10);                      // SHOW THE ROW FOR 10 Ms

	    LEDMATRIX_voidTurnOff();                       // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[3]);             // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(LED_MATRIX_COL_3,LOW);      // SELECT COLOUMN 3
		SYSTICK_voidBusyWait(10);                      // SHOW THE ROW FOR 10 Ms

	    LEDMATRIX_voidTurnOff();                       // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[4]);             // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(LED_MATRIX_COL_4,LOW);      // SELECT COLOUMN 4
		SYSTICK_voidBusyWait(10);                      // SHOW THE ROW FOR 10 Ms

	    LEDMATRIX_voidTurnOff();                       // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[5]);             // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(LED_MATRIX_COL_5,LOW);      // SELECT COLOUMN 5
		SYSTICK_voidBusyWait(10);                      // SHOW THE ROW FOR 10 Ms

	    LEDMATRIX_voidTurnOff();                       // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[6]);             // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(LED_MATRIX_COL_6,LOW);      // SELECT COLOUMN 6
		SYSTICK_voidBusyWait(10);                      // SHOW THE ROW FOR 10 Ms

	    LEDMATRIX_voidTurnOff();                       // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[7]);             // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(LED_MATRIX_COL_7,LOW);      // SELECT COLOUMN 7
		SYSTICK_voidBusyWait(10);                      // SHOW THE ROW FOR 10 Ms


	    LEDMATRIX_voidTurnOff();                       // DEACTIVATE ALL THE COLOUMNS
		SYSTICK_voidBusyWait(10);                      // SHOW THE ROW FOR 10 Ms

}


void LEDMATRIX_voidDispCharShifted(u8 *PTR_ARR,u8 Copy_u8ShiftVal)
{


	    LEDMATRIX_voidTurnOff();                                    // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[0]);                          // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(COLOUMNS_PORT,Copy_u8ShiftVal,LOW);      // SHIFT THE DISPLAY
		SYSTICK_voidBusyWait(10);                                   // SHOW THE ROW FOR 10 Ms

		Copy_u8ShiftVal++;

	    LEDMATRIX_voidTurnOff();                                    // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[1]);                          // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(COLOUMNS_PORT,Copy_u8ShiftVal,LOW);      // SHIFT THE DISPLAY
		SYSTICK_voidBusyWait(10);                                   // SHOW THE ROW FOR 10 Ms

		Copy_u8ShiftVal++;

	    LEDMATRIX_voidTurnOff();                   				    // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[2]);           				// DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(COLOUMNS_PORT,Copy_u8ShiftVal,LOW);      // SHIFT THE DISPLAY
		SYSTICK_voidBusyWait(10);                     			    // SHOW THE ROW FOR 10 Ms

		Copy_u8ShiftVal++;

	    LEDMATRIX_voidTurnOff();                  				     // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[3]);            				 // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(COLOUMNS_PORT,Copy_u8ShiftVal,LOW);       // SHIFT THE DISPLAY
		SYSTICK_voidBusyWait(10);                      				 // SHOW THE ROW FOR 10 Ms

		Copy_u8ShiftVal++;

	    LEDMATRIX_voidTurnOff();                    			     // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[4]);          				 // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(COLOUMNS_PORT,Copy_u8ShiftVal,LOW);       // SHIFT THE DISPLAY
		SYSTICK_voidBusyWait(10);                   				 // SHOW THE ROW FOR 10 Ms

		Copy_u8ShiftVal++;

	    LEDMATRIX_voidTurnOff();                    				 // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[5]);           			     // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(COLOUMNS_PORT,Copy_u8ShiftVal,LOW);       // SHIFT THE DISPLAY
		SYSTICK_voidBusyWait(10);                     				 // SHOW THE ROW FOR 10 Ms

		Copy_u8ShiftVal++;

	    LEDMATRIX_voidTurnOff();                    		         // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[6]);            			     // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(COLOUMNS_PORT,Copy_u8ShiftVal,LOW);       // SHIFT THE DISPLAY
		SYSTICK_voidBusyWait(10);                     			     // SHOW THE ROW FOR 10 Ms

		Copy_u8ShiftVal++;

	    LEDMATRIX_voidTurnOff();                      			     // DEACTIVATE ALL THE COLOUMNS
		LEDMATRIX_voidRowDisp(PTR_ARR[7]);           			     // DISPLAY THE LEDS ON THE GIVEN ROW
		GPIO_voidSetPinVal(COLOUMNS_PORT,Copy_u8ShiftVal,LOW);       // SHIFT THE DISPLAY
		SYSTICK_voidBusyWait(10);                     			     // SHOW THE ROW FOR 10 Ms




	    LEDMATRIX_voidTurnOff();                     			      // DEACTIVATE ALL THE COLOUMNS
		SYSTICK_voidBusyWait(10);                     		          // SHOW THE ROW FOR 10 Ms

}







