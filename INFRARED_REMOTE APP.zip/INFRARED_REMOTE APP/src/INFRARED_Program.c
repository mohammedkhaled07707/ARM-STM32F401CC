
/******************************************************/
/* SWC: INFRARED Driver                               */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 13 OCT 2023                                  */
/* Description: This is the implem. INFRARED          */
/******************************************************/

#include "INFRARED_Config.h"
#include "INFRARED_Interface.h"
#include "INFRARED_Private.h"
#include "STD_TYPES.h"
#include "MACROS.h"
#include "SYSTICK_Interface.h"
#include "EXTINT_Interface.h"
#include "GPIO_Interface.h"

u32   COUNTER = 0;
static u8    DATA;
u32   RECIEVED_DATA[33];
u8    START_FLAG = 0;



/* WORKING PRINCIPLE: IR IS A COMMUNICATION PROTOCOL BASED ON INFRARED TRANSMITTER AND RECIEVER WHEN YOU SEND A SIGNAL
TO THE IR RECIEVER THE 0 AND 1 ARE REPRESENTED AS THE DURATION BETWEEN 2 FALLING EDGE

0 IS REPRESENTED AS TIME BETWEEN 1000 AND 1200
1 IS REPRESENTED AS TIME BETWEEN 2000 AND 2500
START BIT IS REPRESENTED AS TIME BETWEEN 10000 AND 15000

WITH EVERY SIGNAL THERE IS A FRAME OF 33 BIT

1 START BIT  8 ADDRESS BITS 8 ADDRESS BITS INVERSED 8 DATA BITS 8 DATA BITS INVERSED

THE INVERSE ARE FOR ERROR CHECKING TO CHECK WETHER THE DATA ARE SENT CORRECTLY OR CORUPTED

TO GET THE DATA YOU WILL RECIEVE THE FRAME IN A 33 BIT ARRAY THEN CHANGE THE ARRAY TO BINARY TO GET THE DATA*/



// NOTE: RCC IS WORKING ON AHB WITH PRESCALAR/2  AND SYSTICK IS WORKING ON AHB/8


/****************************************************************************/
/* Func. Name: INFRARED_voidRecieve					                        */
/* i/p arguments: NOTHING                                                   */
/* o/p arguments: NOTHING                                                   */
/* Desc. : RECIEVE THE READINGS FROM THE INFRARED RECIEVER                  */
/****************************************************************************/

void INFRARED_voidRecieve()
{

	if (START_FLAG == 0)
	{
		SYSTICK_voidSingleInterval(1000000,&INFRARED_voidChangeData);    // FALLING EDGE DETECTED START THE TIMER
		START_FLAG = 1;
	}
	else
	{
		RECIEVED_DATA[COUNTER] = SYSTICK_voidElapsedTime();              // GET THE ELAPSED TIME AND SAVE IT IN AN ARRAY
		SYSTICK_voidSingleInterval(1000000,&INFRARED_voidChangeData);    // START THE SYSTICK AGAIN TO DETECT THE TIME FOR NEXT EDGE
		COUNTER++;
	}

}

/****************************************************************************/
/* Func. Name: INFRARED_voidChangeData				                        */
/* i/p arguments: NOTHING                                                   */
/* o/p arguments: NOTHING                                                   */
/* Desc. : CHANGE THE READINGS RECIEVED TO BINARY                           */
/****************************************************************************/


void INFRARED_voidChangeData()
{
	   u8 LOCAL_COUNTER = 0;
	   START_FLAG = 0;


	   for (LOCAL_COUNTER = 0;LOCAL_COUNTER < 8;LOCAL_COUNTER++)                                         // GET THE READINGS OF DATA
	   {

		   if((10000<=RECIEVED_DATA[0]) && (RECIEVED_DATA[0]<=15000))                                    // START BIT RANGE IS BETWEEN 10000 AND 15000
		   {
		   if ((1000<= RECIEVED_DATA[17+LOCAL_COUNTER]) && (RECIEVED_DATA[17+LOCAL_COUNTER]<=1200))      // ZERO RANGE IS BETWEEN 1000 AND 1200
		   {
			   CLR_BIT(DATA,LOCAL_COUNTER);                                                              // CLR THE BIT OF DATA
		   }
		   if ((2000<= RECIEVED_DATA[17+LOCAL_COUNTER]) && (RECIEVED_DATA[17+LOCAL_COUNTER]<=2500))      // ONE RANGE IS BETWEEN 2000 AND 2500
		   {
			   SET_BIT(DATA,LOCAL_COUNTER);                                                              // SET THE BIT OF DATA
		   }
		   }

	   }

COUNTER= 0;

}

/****************************************************************************/
/* Func. Name: INFRARED_voidGetReading				                        */
/* i/p arguments: NOTHING                                                   */
/* o/p arguments: u8 CHANGED_DATA                                           */
/* Desc. : RETURNS THE ACTUAL DATA AFTER CONVERSION                         */
/****************************************************************************/

u8 INFRARED_voidGetReading()
{
	u8 CHANGED_DATA = 0;
	CHANGED_DATA = DATA;

	return CHANGED_DATA;
}
