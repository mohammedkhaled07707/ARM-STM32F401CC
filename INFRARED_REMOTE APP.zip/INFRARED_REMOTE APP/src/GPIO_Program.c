
/******************************************************/
/* SWC: GPIO Driver                                   */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 28 SEP 2023                                  */
/* Description: This is the implem. GPIO              */
/******************************************************/


#include "STD_TYPES.h"
#include "MACROS.h"
#include "GPIO_Config.h"
#include "GPIO_Interface.h"
#include "GPIO_Private.h"


/*********************************************************************************************/
/* Func. Name: GPIO_voidSetPinMode					                                         */
/* i/p arguments:Cpy_u8PortName >> PORT(A,B,C)                                               */
/* i/p arguments:Cpy_u8PinNum >> PIN(0...15)                                                 */
/* i/p arguments:Cpy_u8PinNum >> (INPUT_MODE, OUTPUT_MODE, ALTERNATE_FUNCTION, ANALOG_MODE)  */
/* o/p arguments: NOTHING                                                                    */
/* Desc. : SET THE SELECTED PORT MODE                                                        */
/*********************************************************************************************/

void GPIO_voidSetPinMode(u8 Cpy_u8PortName,u8 Cpy_u8PinNum,u8 Cpy_u8PinMode)
{

	switch (Cpy_u8PortName)                                         // SWITCH BETWEEN PORT A,B,C
	{
	case PORTA:
		switch (Cpy_u8PinMode)                                      // SWITCH BETWEEN 4 PINMODES (INP,OUT,ALTERNATE,ANALOG)
		{
		case INPUT_MODE:

			CLR_BIT(GPIOA_REG->MODER,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOA_REG->MODER,((Cpy_u8PinNum*2)+1));

			break;

		case OUTPUT_MODE:

			SET_BIT(GPIOA_REG->MODER,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOA_REG->MODER,((Cpy_u8PinNum*2)+1));

			break;

		case ALTERATE_FUNCTION:

			CLR_BIT(GPIOA_REG->MODER,(Cpy_u8PinNum*2));
			SET_BIT(GPIOA_REG->MODER,((Cpy_u8PinNum*2)+1));

			break;

		case ANALOG_MODE:

			SET_BIT(GPIOA_REG->MODER,(Cpy_u8PinNum*2));
			SET_BIT(GPIOA_REG->MODER,((Cpy_u8PinNum*2)+1));

			break;

		}
	break;

	case PORTB:
		switch (Cpy_u8PinMode)                                   // SWITCH BETWEEN 4 PINMODES (INP,OUT,ALTERNATE,ANALOG)
		{
		case INPUT_MODE:

			CLR_BIT(GPIOB_REG->MODER,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOB_REG->MODER,((Cpy_u8PinNum*2)+1));

			break;

		case OUTPUT_MODE:

			SET_BIT(GPIOB_REG->MODER,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOB_REG->MODER,((Cpy_u8PinNum*2)+1));

			break;

		case ALTERATE_FUNCTION:

			CLR_BIT(GPIOB_REG->MODER,(Cpy_u8PinNum*2));
			SET_BIT(GPIOB_REG->MODER,((Cpy_u8PinNum*2)+1));

			break;

		case ANALOG_MODE:

			SET_BIT(GPIOB_REG->MODER,(Cpy_u8PinNum*2));
			SET_BIT(GPIOB_REG->MODER,((Cpy_u8PinNum*2)+1));

			break;

		}
	break;

	case PORTC:
		switch (Cpy_u8PinMode)                                   // SWITCH BETWEEN 4 PINMODES (INP,OUT,ALTERNATE,ANALOG)
		{
		case INPUT_MODE:

			CLR_BIT(GPIOC_REG->MODER,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOC_REG->MODER,((Cpy_u8PinNum*2)+1));

			break;

		case OUTPUT_MODE:

		    SET_BIT(GPIOC_REG->MODER,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOC_REG->MODER,((Cpy_u8PinNum*2)+1));

			break;

		case ALTERATE_FUNCTION:

			CLR_BIT(GPIOC_REG->MODER,(Cpy_u8PinNum*2));
			SET_BIT(GPIOC_REG->MODER,((Cpy_u8PinNum*2)+1));

			break;

		case ANALOG_MODE:

			SET_BIT(GPIOC_REG->MODER,(Cpy_u8PinNum*2));
			SET_BIT(GPIOC_REG->MODER,((Cpy_u8PinNum*2)+1));

			break;

		}
	break;

	}

}

/*********************************************************************************************/
/* Func. Name: GPIO_voidSetOutputMode					                                     */
/* i/p arguments:Cpy_u8PortName >> PORT(A,B,C)                                               */
/* i/p arguments:Cpy_u8PinNum >> PIN(0...15)                                                 */
/* i/p arguments:Cpy_u8PinOutputMode >> (PUSH_PULL_MODE, OPEN_DRAIN_MODE)                    */
/* o/p arguments: NOTHING                                                                    */
/* Desc. : SET THE SELECTED PORT MODE                                                        */
/*********************************************************************************************/

void GPIO_voidSetOutputMode(u8 Cpy_u8PortName,u8 Cpy_u8PinNum,u8 Cpy_u8PinOutputMode)
{
	switch (Cpy_u8PortName)
	{
	case PORTA:
		switch(Cpy_u8PinOutputMode)
		{

		case PUSH_PULL_MODE:
			CLR_BIT(GPIOA_REG->OTYPER,Cpy_u8PinNum);
			break;
		case OPEN_DRAIN_MODE:
			SET_BIT(GPIOA_REG->OTYPER,Cpy_u8PinNum);
			break;

		}
    break;


	case PORTB:
		switch(Cpy_u8PinOutputMode)
		{

		case PUSH_PULL_MODE:
			CLR_BIT(GPIOB_REG->OTYPER,Cpy_u8PinNum);
			break;
		case OPEN_DRAIN_MODE:
			SET_BIT(GPIOB_REG->OTYPER,Cpy_u8PinNum);
			break;

		}

	break;

	case PORTC:
		switch(Cpy_u8PinOutputMode)
		{

		case PUSH_PULL_MODE:
			CLR_BIT(GPIOC_REG->OTYPER,Cpy_u8PinNum);
			break;
		case OPEN_DRAIN_MODE:
			SET_BIT(GPIOC_REG->OTYPER,Cpy_u8PinNum);
			break;

		}

	break;

	}
}

/****************************************************************************************************************/
/* Func. Name: GPIO_voidSetSpeed					                                                            */
/* i/p arguments:Cpy_u8PortName >> PORT(A,B,C)                                                                  */
/* i/p arguments:Cpy_u8PinNum >> PIN(0...15)                                                                    */
/* i/p arguments:Cpy_u8SpeedMode >> (LOW_SPEED_MODE, MEDIUM_SPEED_MODE, HIGH_MODE_SPEED, VERY_HIGH_SPEED_MODE)  */
/* o/p arguments: NOTHING                                                                                       */
/* Desc. : SET THE SELECTED PIN SPEED                                                                           */
/****************************************************************************************************************/

void GPIO_voidSetSpeed(u8 Cpy_u8PortName,u8 Cpy_u8PinNum,u8 Cpy_u8SpeedMode)
{

	switch (Cpy_u8PortName)
	{
	case PORTA:
		switch (Cpy_u8SpeedMode)
		{
		case LOW_SPEED_MODE:

			CLR_BIT(GPIOA_REG->OSPEEDR,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOA_REG->OSPEEDR,((Cpy_u8PinNum*2)+1));

			break;

		case MEDIUM_SPEED_MODE:

			SET_BIT(GPIOA_REG->OSPEEDR,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOA_REG->OSPEEDR,((Cpy_u8PinNum*2)+1));

			break;

		case HIGH_SPEED_MODE:

			CLR_BIT(GPIOA_REG->OSPEEDR,(Cpy_u8PinNum*2));
			SET_BIT(GPIOA_REG->OSPEEDR,((Cpy_u8PinNum*2)+1));

			break;

		case VERY_HIGH_SPEED_MODE:

			SET_BIT(GPIOA_REG->OSPEEDR,(Cpy_u8PinNum*2));
			SET_BIT(GPIOA_REG->OSPEEDR,((Cpy_u8PinNum*2)+1));

			break;

		}
	break;

	case PORTB:
		switch (Cpy_u8SpeedMode)
		{
		case LOW_SPEED_MODE:

			CLR_BIT(GPIOB_REG->OSPEEDR,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOB_REG->OSPEEDR,((Cpy_u8PinNum*2)+1));

			break;

		case MEDIUM_SPEED_MODE:

			SET_BIT(GPIOB_REG->OSPEEDR,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOB_REG->OSPEEDR,((Cpy_u8PinNum*2)+1));

			break;

		case HIGH_SPEED_MODE:

			CLR_BIT(GPIOB_REG->OSPEEDR,(Cpy_u8PinNum*2));
			SET_BIT(GPIOB_REG->OSPEEDR,((Cpy_u8PinNum*2)+1));

			break;

		case VERY_HIGH_SPEED_MODE:

			SET_BIT(GPIOB_REG->OSPEEDR,(Cpy_u8PinNum*2));
			SET_BIT(GPIOB_REG->OSPEEDR,((Cpy_u8PinNum*2)+1));

			break;

		}
	break;

	case PORTC:
		switch (Cpy_u8SpeedMode)
		{
		case LOW_SPEED_MODE:

			CLR_BIT(GPIOC_REG->OSPEEDR,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOC_REG->OSPEEDR,((Cpy_u8PinNum*2)+1));

			break;

		case MEDIUM_SPEED_MODE:

		    SET_BIT(GPIOC_REG->OSPEEDR,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOC_REG->OSPEEDR,((Cpy_u8PinNum*2)+1));

			break;

		case HIGH_SPEED_MODE:

			CLR_BIT(GPIOC_REG->OSPEEDR,(Cpy_u8PinNum*2));
			SET_BIT(GPIOC_REG->OSPEEDR,((Cpy_u8PinNum*2)+1));

			break;

		case VERY_HIGH_SPEED_MODE:

			SET_BIT(GPIOC_REG->OSPEEDR,(Cpy_u8PinNum*2));
			SET_BIT(GPIOC_REG->OSPEEDR,((Cpy_u8PinNum*2)+1));

			break;

		}
	break;

	}

}

/****************************************************************************************************************/
/* Func. Name: GPIO_voidSetInputPUPD					                                                        */
/* i/p arguments:Cpy_u8PortName >> PORT(A,B,C)                                                                  */
/* i/p arguments:Cpy_u8PinNum >> PIN(0...15)                                                                    */
/* i/p arguments:Cpy_u8InputMode >> (FLOAT_MODE, PULLUP_MODE, PULLDOWN_SPEED)                                   */
/* o/p arguments: NOTHING                                                                                       */
/* Desc. : SET THE SELECTED PIN INPUT MODE                                                                      */
/****************************************************************************************************************/

void GPIO_voidSetInputPUPD(u8 Cpy_u8PortName,u8 Cpy_u8PinNum,u8 Cpy_u8InputMode)
{

	switch (Cpy_u8PortName)
	{
	case PORTA:
		switch (Cpy_u8InputMode)
		{
		case FLOAT_MODE:

			CLR_BIT(GPIOA_REG->PUPDR,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOA_REG->PUPDR,((Cpy_u8PinNum*2)+1));

			break;

		case PULLUP_MODE:

			SET_BIT(GPIOA_REG->PUPDR,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOA_REG->PUPDR,((Cpy_u8PinNum*2)+1));

			break;

		case PULLDOWN_MODE:

			CLR_BIT(GPIOA_REG->PUPDR,(Cpy_u8PinNum*2));
			SET_BIT(GPIOA_REG->PUPDR,((Cpy_u8PinNum*2)+1));

			break;


		}
	break;

	case PORTB:
		switch (Cpy_u8InputMode)
		{
		case FLOAT_MODE:

			CLR_BIT(GPIOB_REG->PUPDR,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOB_REG->PUPDR,((Cpy_u8PinNum*2)+1));

			break;

		case PULLUP_MODE:

			SET_BIT(GPIOB_REG->PUPDR,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOB_REG->PUPDR,((Cpy_u8PinNum*2)+1));

			break;

		case PULLDOWN_MODE:

			CLR_BIT(GPIOB_REG->PUPDR,(Cpy_u8PinNum*2));
			SET_BIT(GPIOB_REG->PUPDR,((Cpy_u8PinNum*2)+1));

			break;


		}
	break;

	case PORTC:
		switch (Cpy_u8InputMode)
		{
		case FLOAT_MODE:

			CLR_BIT(GPIOC_REG->PUPDR,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOC_REG->PUPDR,((Cpy_u8PinNum*2)+1));

			break;

		case PULLUP_MODE:

		    SET_BIT(GPIOC_REG->PUPDR,(Cpy_u8PinNum*2));
			CLR_BIT(GPIOC_REG->PUPDR,((Cpy_u8PinNum*2)+1));

			break;

		case PULLDOWN_MODE:

			CLR_BIT(GPIOC_REG->PUPDR,(Cpy_u8PinNum*2));
			SET_BIT(GPIOC_REG->PUPDR,((Cpy_u8PinNum*2)+1));

			break;


		}
	break;

	}


}

/****************************************************************************************************************/
/* Func. Name: GPIO_u8GetPinVal     					                                                        */
/* i/p arguments:Cpy_u8PortName >> PORT(A,B,C)                                                                  */
/* i/p arguments:Cpy_u8PinNum >> PIN(0...15)                                                                    */
/* o/p arguments: PIN_VAL                                                                                       */
/* Desc. : RETURN THE VALUE OF THE SELECTED PIN                                                                 */
/****************************************************************************************************************/

u8 GPIO_u8GetPinVal(u8 Cpy_u8PortName,u8 Cpy_u8PinNum)
{
	u8 PIN_VAL = 0;

	switch(Cpy_u8PortName)
	{
	case PORTA:
		PIN_VAL = GET_BIT(GPIOA_REG->IDR,Cpy_u8PinNum);
		break;

	case PORTB:
		PIN_VAL = GET_BIT(GPIOB_REG->IDR,Cpy_u8PinNum);
		break;

	case PORTC:
		PIN_VAL = GET_BIT(GPIOC_REG->IDR,Cpy_u8PinNum);
		break;

	}

	return PIN_VAL;

}

/****************************************************************************************************************/
/* Func. Name: GPIO_voidSetInputPUPD					                                                        */
/* i/p arguments:Cpy_u8PortName >> PORT(A,B,C)                                                                  */
/* i/p arguments:Cpy_u8PinNum >> PIN(0...15)                                                                    */
/* i/p arguments:Cpy_u8PinVal >> (HIGH, LOW)                                                                    */
/* o/p arguments: NOTHING                                                                                       */
/* Desc. : SET THE SELECTED PIN VAL                                                                             */
/****************************************************************************************************************/

void GPIO_voidSetPinVal(u8 Cpy_u8PortName,u8 Cpy_u8PinNum,u8 Cpy_u8PinVal)
{

	switch(Cpy_u8PortName)
	{
	case PORTA:
		switch(Cpy_u8PinVal)
		{
		case HIGH:
		SET_BIT(GPIOA_REG->ODR,Cpy_u8PinNum);
		break;
		case LOW:
		CLR_BIT(GPIOA_REG->ODR,Cpy_u8PinNum);
		break;
		}
	break;


	case PORTB:
		switch(Cpy_u8PinVal)
		{
		case HIGH:
		SET_BIT(GPIOB_REG->ODR,Cpy_u8PinNum);
		break;
		case LOW:
		CLR_BIT(GPIOB_REG->ODR,Cpy_u8PinNum);
		break;
		}
	break;

	case PORTC:
		switch(Cpy_u8PinVal)
		{
		case HIGH:
		SET_BIT(GPIOC_REG->ODR,Cpy_u8PinNum);
		break;
		case LOW:
		CLR_BIT(GPIOC_REG->ODR,Cpy_u8PinNum);
		break;
		}
	break;

	}

}






