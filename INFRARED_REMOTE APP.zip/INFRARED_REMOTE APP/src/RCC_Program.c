/******************************************************/
/* SWC: RCC Driver                                    */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 27 SEP 2023                                  */
/* Description: This is the implem. RCC               */
/******************************************************/

#include "RCC_Config.h"
#include "RCC_Interface.h"
#include "RCC_Private.h"
#include "STD_TYPES.h"
#include "MACROS.h"



/********************************************************************/
/* Func. Name: RCC_VoidSysClkEnable					                */
/* i/p arguments:NOTHING                                            */
/* o/p arguments: NOTHING                                           */
/* Desc. : INITIALIZE THE SYSTEM CLK                                */
/* select:  NOTHING                                                 */
/********************************************************************/

void RCC_VoidSysClkEnable(void)
{
SET_BIT(RCC_CR,0);         // ENABLE HSI
SET_BIT(RCC_CR,16);        // ENABLE HSE
SET_BIT(RCC_CR,24);        // ENABLE PLL

#if   (SYSCLK_BYPASS == ENABLE)
SET_BIT(RCC_CR,18);
#elif (SYSCLK_BYPASS == DISABLE)
CLR_BIT(RCC_CR,18);
#endif

#if   (CLOCK_SECURITY_SYSTEM == ENABLE)
SET_BIT(RCC_CR,19);
#elif (CLOCK_SECURITY_SYSTEM == DISABLE)
CLR_BIT(RCC_CR,19);
#endif

#if   (CLOCK_SOURCE == HSI_CLOCK)         // SELECT SYSTEM CLOCK
CLR_BIT(RCC_CFGR,0);
CLR_BIT(RCC_CFGR,1);
#elif (CLOCK_SOURCE == HSE_CLOCK)
SET_BIT(RCC_CFGR,0);
CLR_BIT(RCC_CFGR,1);
#elif (CLOCK_SOURCE == PLL_CLOCK )
CLR_BIT(RCC_CFGR,0);
SET_BIT(RCC_CFGR,1);
#else

#warning "SELECT PROPER CLOCK SOURCE";
#endif


#if   (AHB_PRESCALAR ==NO_PRESCALAR)     // SELECT A PRESCALAR FOR AHB BUS
CLR_BIT(RCC_CFGR,4);
CLR_BIT(RCC_CFGR,5);
CLR_BIT(RCC_CFGR,6);
CLR_BIT(RCC_CFGR,7);

#elif (AHB_PRESCALAR == PRESCALAR_2)
CLR_BIT(RCC_CFGR,4);
CLR_BIT(RCC_CFGR,5);
CLR_BIT(RCC_CFGR,6);
SET_BIT(RCC_CFGR,7);

#elif (AHB_PRESCALAR == PRESCALAR_4)
SET_BIT(RCC_CFGR,4);
CLR_BIT(RCC_CFGR,5);
CLR_BIT(RCC_CFGR,6);
SET_BIT(RCC_CFGR,7);

#elif (AHB_PRESCALAR == PRESCALAR_8)
CLR_BIT(RCC_CFGR,4);
SET_BIT(RCC_CFGR,5);
CLR_BIT(RCC_CFGR,6);
SET_BIT(RCC_CFGR,7);

#elif (AHB_PRESCALAR == PRESCALAR_16)
SET_BIT(RCC_CFGR,4);
SET_BIT(RCC_CFGR,5);
CLR_BIT(RCC_CFGR,6);
SET_BIT(RCC_CFGR,7);

#elif (AHB_PRESCALAR == PRESCALAR_64)
CLR_BIT(RCC_CFGR,4);
CLR_BIT(RCC_CFGR,5);
SET_BIT(RCC_CFGR,6);
SET_BIT(RCC_CFGR,7);

#elif (AHB_PRESCALAR == PRESCALAR_128)
SET_BIT(RCC_CFGR,4);
CLR_BIT(RCC_CFGR,5);
SET_BIT(RCC_CFGR,6);
SET_BIT(RCC_CFGR,7);

#elif (AHB_PRESCALAR == PRESCALAR_256)
CLR_BIT(RCC_CFGR,4);
SET_BIT(RCC_CFGR,5);
SET_BIT(RCC_CFGR,6);
SET_BIT(RCC_CFGR,7);

#elif (AHB_PRESCALAR == PRESCALAR_512)
SET_BIT(RCC_CFGR,4);
SET_BIT(RCC_CFGR,5);
SET_BIT(RCC_CFGR,6);
SET_BIT(RCC_CFGR,7);

#else

#warning "SELECT A PROPER PRESCALAR";

#endif

}

/*************************************************************************/
/* Func. Name: RCC_VoidSysClkEnable					                     */
/* i/p arguments: Cpy_u8BusId   >> AHB1_BUS,AHB2_BUS,APB1_BUS,APB2_BUS   */
/* i/p arguments: Cpy_u8PerName >> SELECT FROM INTERFACE FILE            */
/* o/p arguments: NOTHING                                                */
/* Desc. : INITIALIZE THE PRERIPHERAL CLK                                */
/*************************************************************************/

void RCC_VoidPerClkEnable(u8 Cpy_u8BusId,u8 Cpy_u8PerName)
{

	switch(Cpy_u8BusId)       // SELECT THE PER BUS
	{
	case AHB1_BUS:
		SET_BIT(RCC_AHB1ENR,Cpy_u8PerName);  // ENABLE THE PER IN AHB1
		break;

	case AHB2_BUS:
		SET_BIT(RCC_AHB2ENR,Cpy_u8PerName);  // ENABLE THE PER IN AHB2
		break;

	case APB1_BUS:
		SET_BIT(RCC_APB1ENR,Cpy_u8PerName);  // ENABLE THE PER IN APB1
		break;

	case APB2_BUS:
		SET_BIT(RCC_APB2ENR,Cpy_u8PerName);  // ENABLE THE PER IN APB2
		break;
	}


}





void RCC_VoidPerClkDisable(u8 Cpy_u8BusId,u8 Cpy_u8PerName)
{
	switch(Cpy_u8BusId)
	{
	case AHB1_BUS:
		CLR_BIT(RCC_AHB1ENR,Cpy_u8PerName);  // DISABLE THE PER IN AHB1
		break;

	case AHB2_BUS:
		CLR_BIT(RCC_AHB2ENR,Cpy_u8PerName);  // DISABLE THE PER IN AHB2
		break;

	case APB1_BUS:
		CLR_BIT(RCC_APB1ENR,Cpy_u8PerName);  // DISABLE THE PER IN APB1
		break;

	case APB2_BUS:
		CLR_BIT(RCC_APB2ENR,Cpy_u8PerName);  // DISABLE THE PER IN APB2
		break;
	}
}


















