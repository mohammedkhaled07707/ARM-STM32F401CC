
/******************************************************/
/* SWC: UART DRIVER                                   */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 02 OCT 2023                                  */
/* Description: This is the implem. UART DRIVER       */
/******************************************************/


#include "UART_Config.h"
#include "UART_Interface.h"
#include "UART_Private.h"
#include "STD_TYPES.h"
#include "MACROS.h"


/*************************************************************************************************************************************/
/* Func. Name: UART_VoidInit																			                             */
/* i/p arguments: U16_CpyBaudRate																			                         */
/* o/p arguments: NOTHING                                                                                                            */
/* Desc. : INITIALIZE THE UART COMM. PROTOCOL                                                                                        */
/* select:   PARTIY_MODE , INTERRUPT(ENABLE,DISABLE) , CHARACTER_SIZE , NUM_OF_STOP_BITS , DOUBLE_SPEED , UART_MODE FROM CONFIG FILE */
/*************************************************************************************************************************************/

void UART_VoidInit(u16 U16_CpyBaudRate)
{
	u8 value = 0;


	#if   (UART_MODE == ASYNCHRONOUS)                 // SELECT ASYNCHRONOUS OR SYNCHRONOUS FROM UART MODE IN CONFIG FILE
	CLR_BIT(USART->CR2,11);
	#elif (UART_MODE == SYNCHRONOUS)
	SET_BIT(USART->CR2,11);
	#endif

	#if (PARITY_MODE == EVEN_PARITY)               // SELECT EVEN PARITY IN CONFIG FILE FOR PARITY MODE
	CLR_BIT(USART->CR1,10);

	#elif (PARITY_MODE == ODD_PARITY)                // SELECT ODD PARITY IN CONFIG FILE FOR PARITY MODE
	SET_BIT(USART_CR1,10);
	#endif

	#if   (NUM_OF_STOP_BITS == ONE_BIT)              // SELECT ONE BIT FOR NUMBER OF STOPS IN CONFIG FILE
	CLR_BIT(USART->CR2,12);
	CLR_BIT(USART->CR2,13);
	#elif (NUM_OF_STOP_BITS == TWO_BITS)             // SELECT TWO BITS FOR NUMBER OF STOPS IN CONFIG FILE
	CLR_BIT(USART->CR2,12);
	SET_BIT(USART->CR2,13);
	#endif

	#if (CHARACTER_SIZE==EIGHT_BITS)                  // SELECT THE SIZE OF THE CHARACTER IN THE CONFIG FILE TO FIVE BITS
	SET_BIT(USART->CR1,12);

   #elif (CHARACTER_SIZE == NINE_BITS)
	CLR_BIT(USART->CR1,12);
   #endif



/*	u32 DIV_MANTISSA = 0;
	u32 DIV_FRACTION = 0;

	DIV_MANTISSA = ((16000000/(16*U16_CpyBaudRate)));
	DIV_FRACTION = ((16000000%(16*U16_CpyBaudRate)));

	USART->BRR =  DIV_FRACTION;
	USART->BRR = (DIV_MANTISSA<<4);*/

    USART->BRR = 0x683;


	SET_BIT(USART->CR1,3);                           // ENABLE THE RX REVIEVER BIT
	SET_BIT(USART->CR1,2);                           // ENABLE THE TX RECIEVER BIT
	SET_BIT(USART->CR1,13);                          // ENABLE THE USART BIT

	USART->SR = 0;






}

/**************************************************************/
/* Func. Name: UART_VoidTransmit	                          */
/* i/p arguments: U8_CpyData			    			      */
/* o/p arguments: NOTHING                                     */
/* Desc. : TRANSMIT DATA USING UART                           */
/* select: NOTHING                                            */
/**************************************************************/

void UART_VoidTransmit(u8 U8_CpyData)
{
	while(GET_BIT(USART->SR,6) == 0)           //WAIT WHILE THE REG IS EMPTY THEN CPY THE GIVEN DATA
	{

	}
	USART->DR = U8_CpyData;

}

/**************************************************************/
/* Func. Name: UART_VoidRecieve   	                          */
/* i/p arguments: Data_Recieved			    			      */
/* o/p arguments: NOTHING                                     */
/* Desc. : RECIEVE DATA USING UART                            */
/* select: NOTHING                                            */
/**************************************************************/

void UART_VoidRecieve(u8 *Data_Receieved)
{
	while(GET_BIT(USART->SR,5) == 1)          //WAIT TILL THE READY FLAG TO REC IS SET THEN READ FROM THE UDR
	{

	}
    *Data_Receieved = USART->DR;
}



