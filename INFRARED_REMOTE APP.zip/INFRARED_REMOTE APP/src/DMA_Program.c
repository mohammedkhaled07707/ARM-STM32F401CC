




#include "DMA_Config.h"
#include "DMA_Interface.h"
#include "DMA_Private.h"
#include "STD_TYPES.h"
#include "MACROS.h"


void DMA_voidInit()
{
    // CHANNEL 0 SELECTED

  CLR_BIT(DMA->ch[0].CR,25);
  CLR_BIT(DMA->ch[0].CR,26);
  CLR_BIT(DMA->ch[0].CR,27);

    // SINGLE TRANSFER

  CLR_BIT(DMA->ch[0].CR,23);
  CLR_BIT(DMA->ch[0].CR,24);

    // SINGLE TRANSFER

  CLR_BIT(DMA->ch[0].CR,21);
  CLR_BIT(DMA->ch[0].CR,22);

    // PRIORITY LEVEL

  CLR_BIT(DMA->ch[0].CR,16);
  CLR_BIT(DMA->ch[0].CR,17);

    // MEMORY DATA SIZE

  CLR_BIT(DMA->ch[0].CR,13);
  SET_BIT(DMA->ch[0].CR,14);

   //  PERIPHERAL DATA SIZE

  CLR_BIT(DMA->ch[0].CR,11);
  SET_BIT(DMA->ch[0].CR,12);

   //  PERIPHERAL DATA SIZE

  SET_BIT(DMA->ch[0].CR,9);

    // MEMORY TO MEMORY

  CLR_BIT(DMA->ch[0].CR,6);
  SET_BIT(DMA->ch[0].CR,7);

    // INTERRUPT ENABLE

  SET_BIT(DMA->ch[0].CR,4);


}


void DMA_StartTransferChannel0(u32 *SourceAddress,u32 *DestinationAddress,u16 length)
{

	// STREAM DISABLED

    CLR_BIT(DMA->ch[0].CR,0);


    DMA->ch[0].NDTR = length;
    DMA->ch[0].PAR = *DestinationAddress;
    DMA->ch[0].M0AR = *SourceAddress;


	// STREAM ENABLED
    SET_BIT(DMA->ch[0].CR,0);


}


