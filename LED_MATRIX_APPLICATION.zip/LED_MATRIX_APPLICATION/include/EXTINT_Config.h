/******************************************************/
/* SWC: EXTERNAL INTERRUPT DRIVER                     */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 28 SEP 2023                                  */
/* Description: This is the implem. EXTERNAL INTERRUPT*/
/******************************************************/

#ifndef EXTINT_CONFIG_H_
#define EXTINT_CONFIG_H_





#endif /* EXTINT_CONFIG_H_ */
