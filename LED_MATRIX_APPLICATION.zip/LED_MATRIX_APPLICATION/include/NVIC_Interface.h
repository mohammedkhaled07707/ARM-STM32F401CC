/******************************************************/
/* SWC: NVIC Driver                                   */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 30 SEP 2023                                  */
/* Description: This is the implem. NVIC              */
/******************************************************/
#ifndef NVIC_INTERFACE_H_
#define NVIC_INTERFACE_H_

#include "STD_TYPES.h"



void NVIC_voidInit();

void NVIC_voidSetIntEnable(u8 Cpy_u8InterrputName);

void NVIC_voidSetIntDisable(u8 Cpy_u8InterrputName);

void NVIC_voidSetPendingFlag(u8 Cpy_u8InterrputName);

void NVIC_voidClearPendingFlag(u8 Cpy_u8InterrputName);

void NVIC_voidSetPriority(u8 Cpy_u8IntName,u8 Cpy_u8GrpNum,u8 Cpy_u8SubNum);



#endif /* NVIC_INTERFACE_H_ */
