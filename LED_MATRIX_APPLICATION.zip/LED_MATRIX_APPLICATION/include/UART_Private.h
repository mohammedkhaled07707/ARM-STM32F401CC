/******************************************************/
/* SWC: UART DRIVER                                   */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 02 OCT 2023                                  */
/* Description: This is the implem. UART DRIVER       */
/******************************************************/


#ifndef UART_PRIVATE_H_
#define UART_PRIVATE_H_

#include "STD_TYPES.h"

typedef struct
{
	u32 SR;
	u32 DR;
	u32 BRR;
	u32 CR1;
	u32 CR2;
	u32 CR3;
	u32 GTPR;

}uart_t;

/***********************  USART BUS: APB2  BASE ADDRESS: 0x40011000  ******************/

#define USART_BASE_ADDRESS 0x40011000

#define USART ((volatile uart_t*)(USART_BASE_ADDRESS))

/***************************************************************************************/


#endif /* UART_PRIVATE_H_ */
