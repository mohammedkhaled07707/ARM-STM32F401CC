/******************************************************/
/* SWC: UART DRIVER                                   */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 02 OCT 2023                                  */
/* Description: This is the implem. UART DRIVER       */
/******************************************************/

#ifndef UART_INTERFACE_H_
#define UART_INTERFACE_H_

#include "STD_TYPES.h"


void UART_VoidRecieve(u8 *Data_Receieved);
void UART_VoidTransmit(u8 U8_CpyData);
void UART_VoidInit(u16 U16_CpyBaudRate);

#endif /* UART_INTERFACE_H_ */
