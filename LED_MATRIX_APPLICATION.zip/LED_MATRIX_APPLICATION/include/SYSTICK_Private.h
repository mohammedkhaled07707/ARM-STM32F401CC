/******************************************************/
/* SWC: SYSTICK Driver                                */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 01 OCT 2023                                  */
/* Description: This is the implem. SYSTICK           */
/******************************************************/

#ifndef SYSTICK_PRIVATE_H_
#define SYSTICK_PRIVATE_H_

#include "STD_TYPES.h"


typedef struct
{
	u32 CTRL;
	u32 LOAD;
	u32 VAL;
	u32 CALIB;
}SYSTICK_t;


/********************  SYSTICK BUS: CORE PERIPHERAL   BASE ADDRESS: 0xE000E010 ************************/

#define SYSTICK_BASE_ADDRESS 0xE000E010

#define SYSTICK ((volatile SYSTICK_t*)(SYSTICK_BASE_ADDRESS))

/**************************************************************************8****************************/





#endif /* SYSTICK_PRIVATE_H_ */
