/******************************************************/
/* SWC: UART DRIVER                                   */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 02 OCT 2023                                  */
/* Description: This is the implem. UART DRIVER       */
/******************************************************/


#ifndef UART_CONFIG_H_
#define UART_CONFIG_H_





#endif /* UART_CONFIG_H_ */
