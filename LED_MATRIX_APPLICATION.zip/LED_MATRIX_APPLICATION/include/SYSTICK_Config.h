/******************************************************/
/* SWC: SYSTICK Driver                                */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 01 OCT 2023                                  */
/* Description: This is the implem. SYSTICK           */
/******************************************************/

#ifndef SYSTICK_CONFIG_H_
#define SYSTICK_CONFIG_H_





#endif /* SYSTICK_CONFIG_H_ */
