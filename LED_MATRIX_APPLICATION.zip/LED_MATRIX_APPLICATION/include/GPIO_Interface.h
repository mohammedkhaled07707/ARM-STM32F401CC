/******************************************************/
/* SWC: GPIO Driver                                   */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 28 SEP 2023                                  */
/* Description: This is the implem. GPIO              */
/******************************************************/


#ifndef GPIO_INTERFACE_H_
#define GPIO_INTERFACE_H_

#include "STD_TYPES.h"


///////////////  PORT NAMES /////////////

#define PORTA 0
#define PORTB 1
#define PORTC 2

/////////////////////////////////////////

//////////////  PIN NUMBER  /////////////

#define PIN0  0
#define PIN1  1
#define PIN2  2
#define PIN3  3
#define PIN4  4
#define PIN5  5
#define PIN6  6
#define PIN7  7
#define PIN8  8
#define PIN9  9
#define PIN10 10
#define PIN11 11
#define PIN12 12
#define PIN13 13
#define PIN14 14
#define PIN15 15

/////////////////////////////////////////


////////////// GPIO MODE ////////////////

#define INPUT_MODE        0
#define OUTPUT_MODE       1
#define ALTERATE_FUNCTION 2
#define ANALOG_MODE       3

/////////////////////////////////////////


////////////// OUTPUT MODE //////////////

#define PUSH_PULL_MODE  0
#define OPEN_DRAIN_MODE 1

/////////////////////////////////////////

////////////// SPEED MODES //////////////

#define LOW_SPEED_MODE       0
#define MEDIUM_SPEED_MODE    1
#define HIGH_SPEED_MODE      2
#define VERY_HIGH_SPEED_MODE 3

/////////////////////////////////////////

////////////// INPUT MODES //////////////

#define FLOAT_MODE    0
#define PULLUP_MODE   1
#define PULLDOWN_MODE 2

/////////////////////////////////////////

////////////  OUTPUT VALUES /////////////

#define HIGH 1
#define LOW  0

/////////////////////////////////////////




void GPIO_voidSetPinMode(u8 Cpy_u8PortName,u8 Cpy_u8PinNum,u8 Cpy_u8PinMode);

void GPIO_voidSetOutputMode(u8 Cpy_u8PortName,u8 Cpy_u8PinNum,u8 Cpy_u8PinOutputMode);

void GPIO_voidSetPinVal(u8 Cpy_u8PortName,u8 Cpy_u8PinNum,u8 Cpy_u8PinVal);

u8 GPIO_u8GetPinVal(u8 Cpy_u8PortName,u8 Cpy_u8PinNum);

void GPIO_voidSetInputPUPD(u8 Cpy_u8PortName,u8 Cpy_u8PinNum,u8 Cpy_u8InputMode);

void GPIO_voidSetSpeed(u8 Cpy_u8PortName,u8 Cpy_u8PinNum,u8 Cpy_u8SpeedMode);



#endif /* GPIO_INTERFACE_H_ */
