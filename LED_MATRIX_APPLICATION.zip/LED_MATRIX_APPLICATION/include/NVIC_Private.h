/******************************************************/
/* SWC: NVIC Driver                                   */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 30 SEP 2023                                  */
/* Description: This is the implem. NVIC              */
/******************************************************/
#ifndef NVIC_PRIVATE_H_
#define NVIC_PRIVATE_H_

#include "STD_TYPES.h"

#define VECT_KEY 0x5FA00000


/************* NVIC: CORE PERIPHERAL    NVIC BASE ADDRESS:  0xE000E100    ******************/

#define NVIC_BASE_ADDRESS 0xE000E100

#define ISER_REG  ((volatile u32*)(NVIC_BASE_ADDRESS))
#define ICER_REG  ((volatile u32*)(NVIC_BASE_ADDRESS + 0x80))
#define ISPR_REG  ((volatile u32*)(NVIC_BASE_ADDRESS + 0x100))
#define ICPR_REG  ((volatile u32*)(NVIC_BASE_ADDRESS + 0x180))
#define IABR_REG  ((volatile u32*)(NVIC_BASE_ADDRESS + 0x200))
#define IPR_REG   ((volatile u8*)(NVIC_BASE_ADDRESS + 0x300))

/*************************************************************************************************/

#endif /* NVIC_PRIVATE_H_ */
