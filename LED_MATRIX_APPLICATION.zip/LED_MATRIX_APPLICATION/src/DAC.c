/******************************************************/
/* SWC: DAC DRIVER                                    */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 12 OCT 2023                                  */
/* Description: This is the implem. OF DAC            */
/******************************************************/


#include "MACROS.h"
#include "STD_TYPES.h"
#include "GPIO_Interface.h"
#include "DAC.h"

void DAC_voidInit()
{

u8 Local_Counter = 0;

for (Local_Counter = DAC_PORTSTART; Local_Counter <= DAC_PORTEND;Local_Counter++)
{
	GPIO_voidSetPinMode(DAC_PORT,Local_Counter,OUTPUT_MODE);
	GPIO_voidSetOutputMode(DAC_PORT,Local_Counter,PUSH_PULL_MODE);
	GPIO_voidSetSpeed(DAC_PORT,Local_Counter,LOW_SPEED_MODE);
	GPIO_voidSetPinVal(DAC_PORT,Local_Counter,LOW);

}


}

void DAC_voidSetPortVal(u8 Copy_u8Value )
{
	u8 Local_Counter = 0;

	for (Local_Counter = DAC_PORTSTART; Local_Counter <= DAC_PORTEND;Local_Counter++)
	{

		GPIO_voidSetPinVal(DAC_PORT,Local_Counter,GET_BIT(Copy_u8Value,Local_Counter));

	}

}


void DAC_voidPlaySong(u32 Copy_u8ArraySize,u8 *u8SongArray)
{
	static u32 COUNTER = 0;

	if (COUNTER<Copy_u8ArraySize)
	{
		COUNTER = 0;
	}

	DAC_voidSetPortVal(u8SongArray[COUNTER]);


}












