/******************************************************/
/* SWC: EXTERNAL INTERRUPT DRIVER                     */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 28 SEP 2023                                  */
/* Description: This is the implem. EXTERNAL INTERRUPT*/
/******************************************************/


#include "EXTINT_Config.h"
#include "EXTINT_Interface.h"
#include "EXTINT_Private.h"
#include "STD_TYPES.h"
#include "MACROS.h"

static void (*EXT_PTR[16])(void);


/******************************************************/
/* Func. Name: EXTI_voidSetExtLineEnable      	      */
/* i/p arguments:Copy_u8LineId >> EXT(0...15)_LINE    */
/* o/p arguments: NOTHING                             */
/* Desc. : ENABLE EXT INTERRUPT PIN                   */
/******************************************************/

void EXTI_voidSetExtLineEnable(u8 Copy_u8LineId)
{

	SET_BIT(EXTI->IMR,Copy_u8LineId);


}

/******************************************************/
/* Func. Name: EXTI_voidSetExtLineEnablePendingFlag   */
/* i/p arguments:Copy_u8LineId >> EXT(0...15)_LINE    */
/* o/p arguments: NOTHING                             */
/* Desc. : ENABLE EXT SOFTWARE INTERRUPT PIN          */
/******************************************************/

void EXTI_voidSetExtLineEnablePendingFlag(u8 Copy_u8LineId)
{

	SET_BIT(EXTI->EMR,Copy_u8LineId);


}

/******************************************************/
/* Func. Name: EXTI_voidSetExtLineDisable             */
/* i/p arguments:Copy_u8LineId >> EXT(0...15)_LINE    */
/* o/p arguments: NOTHING                             */
/* Desc. : DISABLE EXT INTERRUPT PIN                  */
/******************************************************/

void EXTI_voidSetExtLineDisable(u8 Copy_u8LineId)
{

	CLR_BIT(EXTI->IMR,Copy_u8LineId);

}

/***********************************************************************************/
/* Func. Name: EXTI_voidSetSenseControl                                            */
/* i/p arguments:Copy_u8LineId >> EXT(0...15)_LINE                                 */
/* i/p arguments:Copy_u8SenseControl >> LOG_CHANGE,FALLING_EDGE AND RISING EDGE    */
/* o/p arguments: NOTHING                     								       */
/* Desc. : SELECT THE SENSE CONTROL ON EXTERNAL INTERRUPT LINE                     */
/***********************************************************************************/

void EXTI_voidSetSenseControl(u8 Copy_u8SenseControl,u8 Copy_u8LineId)
{

switch(Copy_u8SenseControl)                      // SELECTED SENSE CONTROL
{
case FALLING_EDGE:

	SET_BIT(EXTI->FTSR,Copy_u8LineId);           //ENABLE FALLING EDGE BIT
	CLR_BIT(EXTI->RTSR,Copy_u8LineId);           //DISABLE RISING EDGE BIT
	break;

case RISING_EDGE:

	CLR_BIT(EXTI->FTSR,Copy_u8LineId);           //DISABLE FALLING EDGE BIT
	SET_BIT(EXTI->RTSR,Copy_u8LineId);           //ENABLE RISING EDGE BIT
	break;

case LOG_CHANGE:

	SET_BIT(EXTI->FTSR,Copy_u8LineId);           //ENABLE RISING EDGE BIT
	SET_BIT(EXTI->RTSR,Copy_u8LineId);           //ENABLE FALLING EDGE BIT

	break;

}


}

/***********************************************************************************/
/* Func. Name: EXTI_voidSetCallBack                		                           */
/* i/p arguments:Copy_u8LineId >> EXT(0...15)_LINE                                 */
/* i/p arguments:ptr >> PASSING THE FUNCTION FOR IRQ HANDLER                       */
/* o/p arguments: NOTHING                     								       */
/* Desc. : PASSING THE ADDRESS OF THE FUNCTON TO THE IRQ HANDLER                   */
/***********************************************************************************/

void EXTI_voidSetCallBack(u8 Copy_u8LineId,void (*ptr)(void))
{

	EXT_PTR[Copy_u8LineId] = ptr;

}


/***********************************************************************************/
/* Func. Name: EXTI_voidSetExtPinConfig                                            */
/* i/p arguments:Cpy_u8PortName >> PORT(A..C)                                      */
/* i/p arguments:Cpy_u8PinNumber >> PIN (0..15)                                    */
/* o/p arguments: NOTHING                     								       */
/* Desc. : SELECT THE LINE FOR THE EXTERNAL INTERRUPT                              */
/***********************************************************************************/

void EXTI_voidSetExtPinConfig(u8 Cpy_u8PortName,u8 Cpy_u8PinNumber)
{
	switch(Cpy_u8PortName)
	{
	case PORTA:
		SYSCFG_EXTICR[Cpy_u8PinNumber/4] |= (0b0000<<((Cpy_u8PinNumber%4)*4));
		break;
	case PORTB:
		SYSCFG_EXTICR[Cpy_u8PinNumber/4] |= (0b0001<<((Cpy_u8PinNumber%4)*4));
		break;
	case PORTC:
		SYSCFG_EXTICR[Cpy_u8PinNumber/4] |= (0b0010<<((Cpy_u8PinNumber%4)*4));
		break;
	}

}



void EXTI0_IRQHandler(void)
{


	EXT_PTR[EXT0_LINE]();
	SET_BIT(EXTI->PR,0);

}

void EXTI1_IRQHandler(void)
{

	EXT_PTR[EXT1_LINE]();
	SET_BIT(EXTI->PR,1);
}


void EXTI2_IRQHandler(void)
{

	EXT_PTR[EXT2_LINE]();
	SET_BIT(EXTI->PR,2);
}


void EXTI3_IRQHandler(void)
{

	EXT_PTR[EXT3_LINE]();
	SET_BIT(EXTI->PR,3);
}
void EXTI4_IRQHandler(void)
{

	EXT_PTR[EXT4_LINE]();
	SET_BIT(EXTI->PR,4);
}

void EXTI9_5_IRQHandler(void)
{
	EXT_PTR[EXT5_LINE]();
	EXT_PTR[EXT6_LINE]();
	EXT_PTR[EXT7_LINE]();
	EXT_PTR[EXT8_LINE]();
	EXT_PTR[EXT9_LINE]();

	SET_BIT(EXTI->PR,5);
	SET_BIT(EXTI->PR,6);
	SET_BIT(EXTI->PR,7);
	SET_BIT(EXTI->PR,8);
	SET_BIT(EXTI->PR,9);

}

void EXTI15_10_IRQHandler(void)
{
	EXT_PTR[EXT10_LINE]();
	EXT_PTR[EXT11_LINE]();
	EXT_PTR[EXT12_LINE]();
	EXT_PTR[EXT13_LINE]();
	EXT_PTR[EXT14_LINE]();
	EXT_PTR[EXT15_LINE]();


	SET_BIT(EXTI->PR,10);
	SET_BIT(EXTI->PR,11);
	SET_BIT(EXTI->PR,12);
	SET_BIT(EXTI->PR,13);
	SET_BIT(EXTI->PR,14);
	SET_BIT(EXTI->PR,15);


}






