/******************************************************/
/* SWC: SYSTICK Driver                                */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 01 OCT 2023                                  */
/* Description: This is the implem. SYSTICK           */
/******************************************************/

#ifndef SYSTICK_INTERFACE_H_
#define SYSTICK_INTERFACE_H_

#include "STD_TYPES.h"

void SYSTICK_voidInit();

void SYSTICK_voidBusyWait(u32 CPY_u32DelayMs);

void SYSTICK_voidSingleInterval(u32 CPY_u32DelayMs,void (*ptr)(void));

void SYSTICK_voidPeriodicInterval(u32 CPY_u32DelayMs,void (*FunName)(void));




#endif /* SYSTICK_INTERFACE_H_ */
