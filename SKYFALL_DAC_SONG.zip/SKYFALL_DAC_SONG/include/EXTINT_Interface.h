/******************************************************/
/* SWC: EXTERNAL INTERRUPT DRIVER                     */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 28 SEP 2023                                  */
/* Description: This is the implem. EXTERNAL INTERRUPT*/
/******************************************************/



#ifndef EXTINT_INTERFACE_H_
#define EXTINT_INTERFACE_H_

#include"STD_TYPES.h"



/*********** INTERRUPT PORTS **********/

#define PORTA 0
#define PORTB 1
#define PORTC 2

/**************************************/

/*********** INTERRUPT PINS  **********/

#define EXT0_LINE    0
#define EXT1_LINE    1
#define EXT2_LINE    2
#define EXT3_LINE    3
#define EXT4_LINE    4
#define EXT5_LINE    5
#define EXT6_LINE    6
#define EXT7_LINE    7
#define EXT8_LINE    8
#define EXT9_LINE    9
#define EXT10_LINE  10
#define EXT11_LINE  11
#define EXT12_LINE  12
#define EXT13_LINE  13
#define EXT14_LINE  14
#define EXT15_LINE  15

/**************************************/

/***********  SENSE CONTROL  **********/

#define FALLING_EDGE  0
#define RISING_EDGE   1
#define LOG_CHANGE    2

/**************************************/





void EXTI_voidInit();
void EXTI_voidSetExtLineEnable(u8 Copy_u8LineId);
void EXTI_voidSetExtLineDisable(u8 Copy_u8LineId);
void EXTI_voidSetSenseControl(u8 Copy_u8SenseControl,u8 Copy_u8LineId);
void EXTI_voidSetExtPinConfig(u8 Cpy_u8PortId,u8 Cpy_u8LineId);
void EXTI_voidSetCallBack(u8 Copy_u8LineId,void (*ptr)(void));
void EXTI_voidSetExtLineEnablePendingFlag(u8 Copy_u8LineId);








#endif /* EXTINT_INTERFACE_H_ */
