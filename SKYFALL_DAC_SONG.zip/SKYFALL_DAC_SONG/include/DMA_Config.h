/******************************************************/
/* SWC: DMA Driver                                    */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 01 OCT 2023                                  */
/* Description: This is the implem. DMA               */
/******************************************************/
#ifndef DMA_CONFIG_H_
#define DMA_CONFIG_H_


/****************** CHANNEL SELECT ******************/

#define CHANNEL0 0
#define CHANNEL1 1
#define CHANNEL2 2
#define CHANNEL3 3
#define CHANNEL4 4
#define CHANNEL5 5
#define CHANNEL6 6
#define CHANNEL7 7



/*****************************************************/
#endif /* DMA_CONFIG_H_ */
