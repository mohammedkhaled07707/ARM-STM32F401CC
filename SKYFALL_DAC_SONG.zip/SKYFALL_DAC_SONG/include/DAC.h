/******************************************************/
/* SWC: DAC DRIVER                                    */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 12 OCT 2023                                  */
/* Description: This is the implem. OF DAC            */
/******************************************************/



#ifndef DAC_H_
#define DAC_H_

#include "STD_TYPES.h"
#include "GPIO_Interface.h"


/****************** DAC PORT *****************/
#define DAC_PORT PORTA

#define DAC_PORTSTART PIN0
#define DAC_PORTEND   PIN7
/*********************************************/

void DAC_voidInit();

void DAC_voidSetPortVal(u8 Copy_u8Value);

void DAC_voidPlaySong(u32 Copy_u8ArraySize,u8 *u8SongArray);






#endif /* DAC_H_ */
