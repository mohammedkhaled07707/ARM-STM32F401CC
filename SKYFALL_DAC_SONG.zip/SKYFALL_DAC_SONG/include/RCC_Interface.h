/******************************************************/
/* SWC: RCC Driver                                    */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 27 SEP 2023                                  */
/* Description: This is the implem. RCC               */
/******************************************************/


#ifndef RCC_INTERFACE_H_
#define RCC_INTERFACE_H_


#include "STD_TYPES.h"
#include "MACROS.h"




////////////////// BUS IDS ///////////////////

#define AHB1_BUS 0
#define AHB2_BUS 1
#define APB1_BUS 2
#define APB2_BUS 3

//////////////////////////////////////////////


////////// AHB1 ENABLE PERIPHERALS ///////////

#define GPIOA 0
#define GPIOB 1
#define GPIOC 2
#define CRC   12
#define DMA1  21
#define DMA2  22

/////////////////////////////////////////////


////////// AHB2 ENABLE PERIPHERALS //////////

#define OTGFS 7

/////////////////////////////////////////////

////////// APB1 ENABLE PERIPHERALS //////////

#define TIM2     0
#define TIM3     1
#define TIM4     2
#define TIM5     3
#define WWDG     11
#define SPI2     14
#define SPI3     15
#define USART2   17
#define I2C1     21
#define I2C2     22
#define I2C3     23
#define PWR      28

/////////////////////////////////////////////

////////// APB2 ENABLE PERIPHERALS //////////

#define TIM1     0
#define USART1   4
#define USART6   5
#define ADC1     8
#define SDIO     11
#define SPI1     12
#define SPI4     13
#define SYSCFG   14
#define TIM9     16
#define TIM10    17
#define TIM11    18

/////////////////////////////////////////////




void RCC_VoidSysClkEnable(void);

void RCC_VoidPerClkEnable(u8 Cpy_u8BusId,u8 Cpy_u8PerName);

void RCC_VoidPerClkDisable(u8 Cpy_u8BusId,u8 Cpy_u8PerName);


#endif
