/******************************************************/
/* SWC: RCC Driver                                    */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 25 SEP 2023                                  */
/* Description: This is the implem. RCC               */
/******************************************************/






#ifndef STD_TYPES_H
#define STD_TYPES_H



typedef  unsigned char        u8;
typedef  char                 sint8;
typedef  unsigned short int   u16;
typedef  signed short int     sint16;
typedef  unsigned long int    u32;
typedef signed long int       sint32;
typedef long long int         sint64;
typedef float                 f32;
typedef double                d64;


#endif /* TYPES_H_ */



