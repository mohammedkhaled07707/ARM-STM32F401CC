/******************************************************/
/* SWC: LED MATRIX Driver                             */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 06 OCT 2023                                  */
/* Description: This is the implem. LED MATRIX        */
/******************************************************/



#ifndef LED_MATRIX_H_
#define LED_MATRIX_H_



#include "STD_TYPES.h"



/************** LED MATRIX COLOUMN *************/


#define COLOUMNS_PORT PORTA

#define LED_MATRIX_COL_0  PORTA,PIN0
#define LED_MATRIX_COL_1  PORTA,PIN1
#define LED_MATRIX_COL_2  PORTA,PIN2
#define LED_MATRIX_COL_3  PORTA,PIN3
#define LED_MATRIX_COL_4  PORTA,PIN4
#define LED_MATRIX_COL_5  PORTA,PIN5
#define LED_MATRIX_COL_6  PORTA,PIN6
#define LED_MATRIX_COL_7  PORTA,PIN7

/***********************************************/

/***************  LED MATRIX ROW  **************/

#define LED_MATRIX_ROW_0  PORTB,PIN0
#define LED_MATRIX_ROW_1  PORTB,PIN1
#define LED_MATRIX_ROW_2  PORTB,PIN2
#define LED_MATRIX_ROW_3  PORTB,PIN3
#define LED_MATRIX_ROW_4  PORTB,PIN4
#define LED_MATRIX_ROW_5  PORTB,PIN5
#define LED_MATRIX_ROW_6  PORTB,PIN6
#define LED_MATRIX_ROW_7  PORTB,PIN7

/***********************************************/

void LEDMATRIX_voidInit();

void LEDMATRIX_voidTurnOff();

void LEDMATRIX_voidRowDisp(u8 Copy_u8Val);

void LEDMATRIX_voidDispChar(u8 *PTR_ARR);

void LEDMATRIX_voidDispCharShifted(u8 *PTR_ARR,u8 Copy_u8ShiftVal);









#endif /* LED_MATRIX_H_ */
