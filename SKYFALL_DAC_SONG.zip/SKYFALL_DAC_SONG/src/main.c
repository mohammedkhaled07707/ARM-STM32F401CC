

#include <stdio.h>
#include <stdlib.h>


#include "STD_TYPES.h"
#include "MACROS.h"
#include "RCC_Interface.h"
#include "GPIO_Interface.h"
#include "GPIO_Private.h"
#include "NVIC_Interface.h"
#include "SYSTICK_Interface.h"
#include "UART_Interface.h"
#include "EXTINT_Interface.h"
#include "EXTINT_Private.h"
#include "LED_MATRIX.h"
#include "DAC.h"
#include "SKYFALL_SONG.h"



u8 K_LETTER[8] = {0, 126, 16, 40, 68, 2, 0, 0};
u8 M_LETTER[8] = {254, 4, 8, 16, 8, 4, 254, 0};
u8 O_LETTER[8] = {224, 160, 224, 0, 0, 0, 0, 0};
u8 HEART[8] = {0, 28, 60, 124, 248, 124, 60, 28};
u8 N_LETTER[8] = {0, 252, 8, 16, 32, 64, 252, 0};
u8 R_LETTER[8] = {0, 252, 36, 36, 100, 164, 60, 0};



void SONG_PLAY()
{
	DAC_voidPlaySong(48390,skyfall_raw);

}




int main()
{

/*RCC_VoidSysClkEnable();
RCC_VoidPerClkEnable(AHB1_BUS,GPIOA);
RCC_VoidPerClkEnable(AHB1_BUS,GPIOB);
SYSTICK_voidInit();
LEDMATRIX_voidInit();*/

RCC_VoidSysClkEnable();
RCC_VoidPerClkEnable(AHB1_BUS,GPIOA);
RCC_VoidPerClkEnable(AHB1_BUS,GPIOB);
SYSTICK_voidInit();
DAC_voidInit();




while(1)
{

	DAC_voidPlaySong(48390,skyfall_raw);


}


return 0;
}




