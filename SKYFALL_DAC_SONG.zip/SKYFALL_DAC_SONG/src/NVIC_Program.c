/******************************************************/
/* SWC: NVIC Driver                                   */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 30 SEP 2023                                  */
/* Description: This is the implem. NVIC              */
/******************************************************/


#include "NVIC_Config.h"
#include "NVIC_Interface.h"
#include "NVIC_Private.h"
#include "STD_TYPES.h"
#include "MACROS.h"




/******************************************************/
/* Func. Name: NVIC_voidInit      			          */
/* i/p arguments:NOTHING                              */
/* o/p arguments: NOTHING                             */
/* Desc. : INITIALIZE PRIORITY GROUPS                 */
/******************************************************/

void NVIC_voidInit()
{

#ifndef SCB_AIRCR_REG
#define SCB_AIRCR_REG *((volatile u32*)(0xE000ED00 + 0x0c))
#endif

	SCB_AIRCR_REG = (VECT_KEY)|(PRIORITY<<8);

}

/******************************************************/
/* Func. Name: NVIC_voidSetIntEnable      	          */
/* i/p arguments:Cpy_u8InterrputName                  */
/* o/p arguments: NOTHING                             */
/* Desc. : ENABLE PERIPHERAL INTERRUPT                */
/******************************************************/

void NVIC_voidSetIntEnable(u8 Cpy_u8InterrputName)
{

   ISER_REG[Cpy_u8InterrputName/32] = (1<<Cpy_u8InterrputName%32);

}

/******************************************************/
/* Func. Name: NVIC_voidSetIntDisable      	          */
/* i/p arguments:Cpy_u8InterrputName                  */
/* o/p arguments: NOTHING                             */
/* Desc. : DISABLE PERIPHERAL INTERRUPT               */
/******************************************************/

void NVIC_voidSetIntDisable(u8 Cpy_u8InterrputName)
{

   ICER_REG[Cpy_u8InterrputName/32] = (1<<Cpy_u8InterrputName%32);

}

/******************************************************/
/* Func. Name: NVIC_voidSetPendingFlag      	      */
/* i/p arguments:Cpy_u8InterrputName                  */
/* o/p arguments: NOTHING                             */
/* Desc. : SET INTERRUPT PENDING FLAG                 */
/******************************************************/

void NVIC_voidSetPendingFlag(u8 Cpy_u8InterrputName)
{

   ISPR_REG[Cpy_u8InterrputName/32] = (1<<Cpy_u8InterrputName%32);

}

/******************************************************/
/* Func. Name: NVIC_voidClearPendingFlag     	      */
/* i/p arguments:Cpy_u8InterrputName                  */
/* o/p arguments: NOTHING                             */
/* Desc. : CLEAR INTERRUPT PENDING FLAG               */
/******************************************************/

void NVIC_voidClearPendingFlag(u8 Cpy_u8InterrputName)
{

   ICPR_REG[Cpy_u8InterrputName/32] = (1<<Cpy_u8InterrputName%32);


}

/******************************************************/
/* Func. Name: NVIC_voidClearPendingFlag     	      */
/* i/p arguments:Cpy_u8InterrputName                  */
/* i/p arguments:Cpy_u8GrpNum                         */
/* i/p arguments:Cpy_u8SubNum                         */
/* o/p arguments: NOTHING                             */
/* Desc. : SET INTERRUPT PRIORITY                     */
/******************************************************/

void NVIC_voidSetPriority(u8 Cpy_u8IntName,u8 Cpy_u8GrpNum,u8 Cpy_u8SubNum)
{

#if   (PRIORITY == GROUP_16_SUB_0)
  IPR_REG[Cpy_u8IntName] = Cpy_u8GrpNum<<4;
#elif (PRIORITY == GROUP_8_SUB_2)
  IPR_REG[Cpy_u8IntName] = Cpy_u8GrpNum<<5;
  IPR_REG[Cpy_u8IntName] = Cpy_u8SubNum<<4;
#elif (PRIORITY == GROUP_4_SUB_4)
  IPR_REG[Cpy_u8IntName] = Cpy_u8GrpNum<<6;
  IPR_REG[Cpy_u8IntName] = Cpy_u8SubNum<<4;
#elif (PRIORITY == GROUP_2_SUB_8)
  IPR_REG[Cpy_u8IntName] = Cpy_u8GrpNum<<7;
  IPR_REG[Cpy_u8IntName] = Cpy_u8SubNum<<4;
#elif (PRIORITY == GROUP_0_SUB_16)
  IPR_REG[Cpy_u8IntName] = Cpy_u8SubNum<<4;
#endif
}
