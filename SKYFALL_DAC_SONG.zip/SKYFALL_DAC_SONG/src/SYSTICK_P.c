/******************************************************/
/* SWC: SYSICK Driver                                 */
/* Author: MOHAMMED KHALED AHMED                      */
/* Version: v0.0                                      */
/* Date: 27 SEP 2023                                  */
/* Description: This is the implem. SYSTICK           */
/******************************************************/


#include "STD_TYPES.h"
#include "MACROS.h"
#include "SYSTICK_Config.h"
#include "SYSTICK_Interface.h"
#include "SYSTICK_Private.h"

static u8 INTERVAL = 0;
static void(*ARR[2])(void);


/*********************************************************************************************/
/* Func. Name: SYSTICK_voidInit  					                                         */
/* i/p arguments: NOTHING                                                                    */
/* o/p arguments: NOTHING                                                                    */
/* Desc. : INITIALIZE THE SYSTICK                                                            */
/*********************************************************************************************/

void SYSTICK_voidInit()
{

	CLR_BIT(SYSTICK->CTRL,16);

}

/*********************************************************************************************/
/* Func. Name: SYSTICK_voidInit  					                                         */
/* i/p arguments: CPY_u32DelayMs                                                             */
/* o/p arguments: NOTHING                                                                    */
/* Desc. : SET A DELAY IN THE CODE                                                           */
/*********************************************************************************************/

void SYSTICK_voidBusyWait(u32 CPY_u32DelayMs)
{




	 /*ENABLE AHB/8 CLK SOURCE*/
	SET_BIT(SYSTICK->CTRL,2);

	SYSTICK->LOAD = (CPY_u32DelayMs);

	 /*ENABLE SYSTICK REGISTER*/
	SET_BIT(SYSTICK->CTRL,0);


    while (GET_BIT(SYSTICK->CTRL,16) == 0);


	CLR_BIT(SYSTICK->CTRL,16);

}

/*********************************************************************************************/
/* Func. Name: SYSTICK_voidSingleInterval 					                                 */
/* i/p arguments: CPY_u32DelayMs                                                             */
/* i/p arguments: FunName                                                                    */
/* o/p arguments: NOTHING                                                                    */
/* Desc. : USE SYSTICK SINGLE FOR A SINGLE PERIOD                                            */
/*********************************************************************************************/

void SYSTICK_voidSingleInterval(u32 CPY_u32DelayMs,void (*FunName)(void))
{


		SYSTICK->LOAD = (CPY_u32DelayMs);

		INTERVAL = 0;
		 /*ENABLE SYSTICK REGISTER*/

		SET_BIT(SYSTICK->CTRL,0);

		ARR[0] = FunName;

		 /*ENABLE SYSTICK INTTERUPT*/
		SET_BIT(SYSTICK->CTRL,1);


}

/*********************************************************************************************/
/* Func. Name: SYSTICK_voidPeriodicInterval 					                             */
/* i/p arguments: CPY_u32DelayMs                                                             */
/* i/p arguments: FunName                                                                    */
/* o/p arguments: NOTHING                                                                    */
/* Desc. : USE SYSTICK FOR MULTIPLE PERIODS                                                  */
/*********************************************************************************************/

void SYSTICK_voidPeriodicInterval(u32 CPY_u32DelayMs,void (*FunName)(void))
{


	ARR[1] = FunName;

	SYSTICK->LOAD = (CPY_u32DelayMs);

	INTERVAL = 1;

	 /*ENABLE SYSTICK REGISTER*/
	SET_BIT(SYSTICK->CTRL,0);



	 /*ENABLE SYSTICK INTTERUPT*/
	SET_BIT(SYSTICK->CTRL,1);

}





void SysTick_Handler(void)
{
	u8 temp = 0;

	if (INTERVAL == 0)
	{

		ARR[0]();


		 /*DISABLE SYSTICK REGISTER*/
		 /*DISABLE SYSTICK INTERRUPT*/
		CLR_BIT(SYSTICK->CTRL,1);
		CLR_BIT(SYSTICK->CTRL,0);

		SYSTICK ->LOAD= 0;
		SYSTICK ->VAL= 0;

	}

	if(INTERVAL == 1)
	{

		ARR[1]();

		 /*CLEAR SYSTICK UNDERFLOW FLAG */

		temp = GET_BIT(SYSTICK->CTRL,16);
	}


}

